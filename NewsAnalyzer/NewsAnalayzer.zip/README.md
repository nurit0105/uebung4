
#### News Analyzer

Source Code Template for exercise 3 lecture programming 2