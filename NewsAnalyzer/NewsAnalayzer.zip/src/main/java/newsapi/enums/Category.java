package newsapi.enums;

public enum Category {
    business, entertainment, health, science, sports, technology
}
