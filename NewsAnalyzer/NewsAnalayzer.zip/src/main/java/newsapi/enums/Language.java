package newsapi.enums;

public enum Language {
    ar,de,en,es,fr,he,it,nl,no,pt,ru,se,ud,zh
}
